import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, User, LogOut, Package, LayoutDashboard } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { auth } from '../firebase';

export default function Navbar() {
  const { user, isAdmin } = useAuth();
  const { items, setIsCartOpen } = useCart();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await auth.signOut();
    navigate('/');
  };

  const cartItemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <nav className="bg-slate-900 text-white sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center">
            <Link to="/" className="flex items-center gap-2 text-xl font-bold tracking-tight">
              <img src="/Logo.jpeg" alt="The Gift Studio" className="w-8 h-8 rounded-full object-cover" />
              <span className="text-white">The Gift <span className="text-yellow-400">Studio</span></span>
            </Link>
          </div>

          <div className="flex-1 max-w-2xl px-8 hidden md:block">
            <form 
              className="relative"
              onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                const query = formData.get('search');
                if (query) navigate(`/?search=${encodeURIComponent(query.toString())}`);
                else navigate('/');
              }}
            >
              <input
                name="search"
                type="text"
                placeholder="Search products..."
                className="w-full bg-white text-gray-900 rounded-md py-2 px-4 focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
            </form>
          </div>

          <div className="flex items-center gap-6">
            {isAdmin && (
              <Link to="/admin" className="flex items-center gap-1 hover:text-yellow-400 transition-colors">
                <LayoutDashboard className="w-5 h-5" />
                <span className="hidden sm:inline">Admin</span>
              </Link>
            )}

            <button 
              onClick={() => setIsCartOpen(true)}
              className="relative flex items-center gap-1 hover:text-yellow-400 transition-colors"
            >
              <ShoppingCart className="w-6 h-6" />
              {cartItemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-yellow-400 text-slate-900 text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {cartItemCount}
                </span>
              )}
            </button>

            {user ? (
              <div className="relative group">
                <button className="flex items-center gap-2 hover:text-yellow-400 transition-colors py-2">
                  <User className="w-5 h-5" />
                  <span className="hidden sm:inline text-sm truncate max-w-[100px]">{user.displayName || 'Account'}</span>
                </button>
                <div className="absolute right-0 top-full w-48 hidden group-hover:block z-50">
                  <div className="bg-white rounded-md shadow-lg py-1 text-gray-800 ring-1 ring-black ring-opacity-5">
                    <div className="px-4 py-2 text-xs text-gray-500 border-b border-gray-100 truncate">
                      {user.email}
                    </div>
                    <Link to="/orders" className="block px-4 py-2 text-sm hover:bg-gray-100">My Orders</Link>
                    <button 
                      onClick={handleLogout}
                      className="w-full text-left px-4 py-2 text-sm hover:bg-gray-100 flex items-center gap-2 text-red-600"
                    >
                      <LogOut className="w-4 h-4" /> Sign out
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <Link to="/login" className="flex items-center gap-1 hover:text-yellow-400 transition-colors">
                <User className="w-5 h-5" />
                <span className="hidden sm:inline">Sign in</span>
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
