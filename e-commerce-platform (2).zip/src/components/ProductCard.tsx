import React from 'react';
import { ShoppingCart } from 'lucide-react';
import { useCart } from '../context/CartContext';

interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  imageUrl: string;
  category: string;
  inStock?: boolean;
}

const ProductCard: React.FC<{ product: any }> = ({ product }) => {
  const { addToCart } = useCart();
  const isOutOfStock = product.inStock === false;

  return (
    <div className={`bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow flex flex-col ${isOutOfStock ? 'opacity-75' : ''}`}>
      <div className="aspect-square overflow-hidden bg-gray-100 relative">
        <img 
          src={product.imageUrl} 
          alt={product.title} 
          className={`w-full h-full object-cover ${isOutOfStock ? 'grayscale' : ''}`}
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-2 left-2 bg-white/90 px-2 py-1 text-xs font-semibold rounded text-gray-700">
          {product.category}
        </div>
        {isOutOfStock && (
          <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 text-xs font-bold rounded shadow-sm">
            Out of Stock
          </div>
        )}
      </div>
      <div className="p-4 flex flex-col flex-1">
        <h3 className="text-lg font-medium text-gray-900 line-clamp-2 mb-1" title={product.title}>
          {product.title}
        </h3>
        <p className="text-sm text-gray-500 line-clamp-2 mb-4 flex-1">
          {product.description}
        </p>
        <div className="flex items-center justify-between mt-auto">
          <span className="text-xl font-bold text-gray-900">
            ₹{product.price.toFixed(2)}
          </span>
          <button 
            onClick={() => addToCart({
              productId: product.id,
              title: product.title,
              price: product.price,
              imageUrl: product.imageUrl,
              quantity: 1
            })}
            disabled={isOutOfStock}
            className={`px-4 py-2 rounded-md flex items-center gap-2 text-sm font-medium transition-colors ${
              isOutOfStock 
                ? 'bg-gray-200 text-gray-500 cursor-not-allowed' 
                : 'bg-slate-900 hover:bg-slate-800 text-white'
            }`}
          >
            <ShoppingCart className="w-4 h-4" />
            {isOutOfStock ? 'Unavailable' : 'Add'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default ProductCard;
