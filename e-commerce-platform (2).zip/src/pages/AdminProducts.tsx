import React, { useState, useEffect } from 'react';
import { collection, onSnapshot, addDoc, updateDoc, deleteDoc, doc, query, orderBy, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { Plus, Trash2, Loader2, Upload, Edit2 } from 'lucide-react';

const compressImage = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 800;
        const MAX_HEIGHT = 800;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        
        // Compress to JPEG with 0.7 quality to keep it well under Firestore's 1MB limit
        resolve(canvas.toDataURL('image/jpeg', 0.7));
      };
      img.onerror = (error) => reject(error);
    };
    reader.onerror = (error) => reject(error);
  });
};

export default function AdminProducts() {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    category: '',
    inStock: true,
    existingImageUrl: ''
  });

  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [showDeleteAllConfirm, setShowDeleteAllConfirm] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'products'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setProducts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleEdit = (product: any) => {
    setFormData({
      title: product.title,
      description: product.description,
      price: product.price.toString(),
      category: product.category,
      inStock: product.inStock !== false, // default to true if undefined
      existingImageUrl: product.imageUrl
    });
    setEditingId(product.id);
    setIsAdding(true);
    setImageFile(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingId && !imageFile) {
      setErrorMsg("Please select an image");
      return;
    }

    setIsUploading(true);
    setErrorMsg(null);
    try {
      let imageUrl = formData.existingImageUrl;

      // Compress and encode new image if selected
      if (imageFile) {
        imageUrl = await compressImage(imageFile);
        
        // Firestore documents have a 1MB limit. 
        // 900,000 characters in Base64 is safely under the limit.
        if (imageUrl.length > 900000) {
          throw new Error("Image is too large even after compression. Please select a smaller image.");
        }
      }

      if (editingId) {
        await updateDoc(doc(db, 'products', editingId), {
          title: formData.title,
          description: formData.description,
          price: parseFloat(formData.price),
          imageUrl: imageUrl,
          category: formData.category,
          inStock: formData.inStock
        });
      } else {
        await addDoc(collection(db, 'products'), {
          title: formData.title,
          description: formData.description,
          price: parseFloat(formData.price),
          imageUrl: imageUrl,
          category: formData.category,
          inStock: formData.inStock,
          createdAt: new Date().toISOString()
        });
      }
      
      setIsAdding(false);
      setEditingId(null);
      setFormData({ title: '', description: '', price: '', category: '', inStock: true, existingImageUrl: '' });
      setImageFile(null);
    } catch (error) {
      console.error("Error saving product:", error);
      setErrorMsg(`Failed to save product: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setIsUploading(false);
    }
  };

  const executeDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'products', id));
      setDeleteConfirmId(null);
    } catch (error) {
      console.error("Error deleting product:", error);
      setErrorMsg(`Failed to delete product: ${error instanceof Error ? error.message : String(error)}`);
    }
  };

  const executeDeleteAll = async () => {
    try {
      const snapshot = await getDocs(collection(db, 'products'));
      const deletePromises = snapshot.docs.map(document => deleteDoc(doc(db, 'products', document.id)));
      await Promise.all(deletePromises);
      setShowDeleteAllConfirm(false);
    } catch (error) {
      console.error("Error deleting all products:", error);
      setErrorMsg(`Failed to delete all products: ${error instanceof Error ? error.message : String(error)}`);
    }
  };

  return (
    <div>
      {errorMsg && (
        <div className="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md flex justify-between items-center">
          <span>{errorMsg}</span>
          <button onClick={() => setErrorMsg(null)} className="text-red-500 hover:text-red-700 font-bold">×</button>
        </div>
      )}

      {showDeleteAllConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-xl max-w-md w-full mx-4">
            <h3 className="text-lg font-bold text-gray-900 mb-2">Delete All Products</h3>
            <p className="text-gray-600 mb-6">Are you ABSOLUTELY sure you want to delete ALL products? This action cannot be undone.</p>
            <div className="flex justify-end gap-3">
              <button onClick={() => setShowDeleteAllConfirm(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-md font-medium">Cancel</button>
              <button onClick={executeDeleteAll} className="px-4 py-2 bg-red-600 text-white rounded-md font-medium hover:bg-red-700">Yes, Delete All</button>
            </div>
          </div>
        </div>
      )}

      {deleteConfirmId && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-xl max-w-md w-full mx-4">
            <h3 className="text-lg font-bold text-gray-900 mb-2">Delete Product</h3>
            <p className="text-gray-600 mb-6">Are you sure you want to delete this product? This action cannot be undone.</p>
            <div className="flex justify-end gap-3">
              <button onClick={() => setDeleteConfirmId(null)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-md font-medium">Cancel</button>
              <button onClick={() => executeDelete(deleteConfirmId)} className="px-4 py-2 bg-red-600 text-white rounded-md font-medium hover:bg-red-700">Yes, Delete</button>
            </div>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Products</h1>
        <div className="flex gap-3">
          {products.length > 0 && (
            <button 
              onClick={() => setShowDeleteAllConfirm(true)}
              className="bg-red-50 text-red-600 px-4 py-2 rounded-md flex items-center gap-2 text-sm font-medium hover:bg-red-100 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
              Delete All
            </button>
          )}
          <button 
            onClick={() => {
              setIsAdding(!isAdding);
              setEditingId(null);
              setFormData({ title: '', description: '', price: '', category: '', inStock: true, existingImageUrl: '' });
              setImageFile(null);
            }}
            className="bg-slate-900 text-white px-4 py-2 rounded-md flex items-center gap-2 text-sm font-medium hover:bg-slate-800 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Product
          </button>
        </div>
      </div>

      {isAdding && (
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-8">
          <h2 className="text-lg font-semibold mb-4">{editingId ? 'Edit Product' : 'Add New Product'}</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input required type="text" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="w-full border rounded-md px-3 py-2" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Price (₹)</label>
                <input required type="number" step="0.01" min="0" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} className="w-full border rounded-md px-3 py-2" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <input required type="text" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} className="w-full border rounded-md px-3 py-2" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Product Image {editingId && <span className="text-gray-400 font-normal">(Leave empty to keep current)</span>}
                </label>
                <input 
                  required={!editingId}
                  type="file" 
                  accept="image/*"
                  onChange={e => setImageFile(e.target.files?.[0] || null)} 
                  className="w-full border rounded-md px-3 py-1.5 text-sm file:mr-4 file:py-1 file:px-3 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-yellow-50 file:text-yellow-700 hover:file:bg-yellow-100" 
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <textarea required rows={3} value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full border rounded-md px-3 py-2" />
            </div>
            <div className="flex items-center mt-2">
              <input 
                type="checkbox" 
                id="inStock" 
                checked={formData.inStock} 
                onChange={e => setFormData({...formData, inStock: e.target.checked})} 
                className="w-4 h-4 text-yellow-500 border-gray-300 rounded focus:ring-yellow-400" 
              />
              <label htmlFor="inStock" className="ml-2 block text-sm font-medium text-gray-700">
                In Stock
              </label>
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => { setIsAdding(false); setEditingId(null); }} className="px-4 py-2 border rounded-md text-gray-600 hover:bg-gray-50">Cancel</button>
              <button type="submit" disabled={isUploading} className="px-4 py-2 bg-yellow-400 text-slate-900 font-medium rounded-md hover:bg-yellow-500 flex items-center gap-2">
                {isUploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                {isUploading ? 'Saving...' : 'Save Product'}
              </button>
            </div>
          </form>
        </div>
      )}

      {loading ? (
        <div className="flex justify-center p-8"><Loader2 className="w-8 h-8 animate-spin text-blue-600" /></div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {products.map((product) => (
                <tr key={product.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-10 w-10 flex-shrink-0">
                        <img className="h-10 w-10 rounded-md object-cover" src={product.imageUrl} alt="" referrerPolicy="no-referrer" />
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">{product.title}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{product.category}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${product.inStock !== false ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                      {product.inStock !== false ? 'In Stock' : 'Out of Stock'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">₹{product.price.toFixed(2)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button onClick={() => handleEdit(product)} className="text-blue-600 hover:text-blue-900 mr-4">
                      <Edit2 className="w-5 h-5" />
                    </button>
                    <button onClick={() => setDeleteConfirmId(product.id)} className="text-red-600 hover:text-red-900">
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
